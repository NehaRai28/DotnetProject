﻿namespace PracticeCrud.Models
{
    public class AddUserViewModel
    {
        public string Name { set; get; }

        public string Email { set; get; }

        public int PhoneNo { set; get; }

    }
}
