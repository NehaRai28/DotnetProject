﻿using Microsoft.EntityFrameworkCore;
using PracticeCrud.Models.Entities;

namespace PracticeCrud.Data
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
    
        public virtual DbSet<Users> User { get; set; }
    }
}
