﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PracticeCrud.Data;
using PracticeCrud.Models;
using PracticeCrud.Models.Entities;

namespace PracticeCrud.Controllers
{
    //[Route("api/[controller]")]
    //[ApiController]
    public class UserController : Controller
    {
        private readonly ApplicationDbContext dbContext;
        public UserController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(AddUserViewModel addUserViewModel)
        {
            var user = new Models.Entities.Users
            {
                Name = addUserViewModel.Name,
                Email = addUserViewModel.Email,
                PhoneNo = addUserViewModel.PhoneNo
            };

            await dbContext.User.AddAsync(user);
            await dbContext.SaveChangesAsync();

            return View();

        }

        [HttpGet]
        public async Task<IActionResult> List()
        {
            var user = await dbContext.User.ToListAsync();
            return View(user);
        }

        //id passes by here to edit.cshml
        [HttpGet]
        public async Task<IActionResult> Edit(Guid id)
        {
            var user = await dbContext.User.FindAsync(id);
            return View(user);
        }
        
        //use for make changes in db
        [HttpPost]
        public async Task<IActionResult> Edit(Users viewModel)
        {
            var student = await dbContext.User.FindAsync(viewModel.Id);

            if (student is not null)
            {
                student.Name = viewModel.Name;
                student.Email = viewModel.Email;
                student.PhoneNo = viewModel.PhoneNo;
                

                await dbContext.SaveChangesAsync();

            }
            return RedirectToAction("List", "User");
        }

        [HttpGet]
        public IActionResult Delete()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Delete(Users viewModel)
        {
            var student = await dbContext.User
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.Id == viewModel.Id);
            if (student is not null)
            {
                dbContext.User.Remove(viewModel);
                await dbContext.SaveChangesAsync();

            }
            return RedirectToAction("List", "User");
        }
    }
}
